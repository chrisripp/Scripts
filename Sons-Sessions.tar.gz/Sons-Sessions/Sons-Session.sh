#!/bin/bash
files=(~/.Sons-Sessions/*)
cvlc --play-and-exit "${files[RANDOM % ${#files[@]}]}"